import React from 'react';
import UserForm from './components/UserForm';
import UserProfile from './components/UserProfile';
import LanguageSwitcher from './components/LanguageSwitcher';

const App = () => {
    return (
        <div>
            <h1>User Profile Management</h1>
            <LanguageSwitcher />
            <UserForm />
            <UserProfile />
        </div>
    );
};

export default App;