import React, { useContext } from 'react';
import { LanguageContext } from './LanguageProvider';

const translations = {
    en: { greeting: 'Hello World', toggle: 'Switch to Spanish' },
    es: { greeting: 'Hola Mundo', toggle: 'Cambiar a Inglés' },
};

const LanguageSwitcher = () => {
    const { language, toggleLanguage } = useContext(LanguageContext);
    const { greeting, toggle } = translations[language];

    return (
        <div>
            <p>{greeting}</p>
            <button onClick={toggleLanguage}>{toggle}</button>
        </div>
    );
};

export default LanguageSwitcher;