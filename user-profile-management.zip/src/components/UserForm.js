import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { updateUser } from '../slices/userSlice';

const UserForm = () => {
    const [userData, setUserData] = useState({ name: '', email: '', age: '' });
    const dispatch = useDispatch();

    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(updateUser(userData));
        setUserData({ name: '', email: '', age: '' }); // Reset form
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                placeholder="Name"
                value={userData.name}
                onChange={(e) => setUserData({ ...userData, name: e.target.value })}
            />
            <input
                type="email"
                placeholder="Email"
                value={userData.email}
                onChange={(e) => setUserData({ ...userData, email: e.target.value })}
            />
            <input
                type="number"
                placeholder="Age"
                value={userData.age}
                onChange={(e) => setUserData({ ...userData, age: e.target.value })}
            />
            <button type="submit">Save</button>
        </form>
    );
};

export default UserForm;